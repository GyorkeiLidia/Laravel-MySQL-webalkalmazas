<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

Route::get('/', [HomeController::class, 'homepage']);  // function name: homepage

Route::get('/home', [HomeController::class, 'index'])->middleware('auth')->name('home'); 
//ha valaki a loginra kattint, erre az oldalra irányitja

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

Route::get('/post_page', [AdminController::class, 'post_page']);
//utóbbi post_page a function név, amit AdminController.php-ba is kell irni!

Route::post('/add_post', [AdminController::class, 'add_post']);
Route::get('/show_post', [AdminController::class, 'show_post']);
Route::get('/delete_post/{id}', [AdminController::class, 'delete_post']);
Route::get('/update_post/{id}', [AdminController::class, 'update_post']);
Route::post('/edit_post/{id}', [AdminController::class, 'edit_post']);
Route::get('/download_image/{id}', [AdminController::class, 'download_image']);

////3 táblázatnak 'R'
Route::get('/school_page', [AdminController::class, 'school_page']);
Route::get('/student_page', [AdminController::class, 'student_page']);
Route::get('/house_page', [AdminController::class, 'house_page']);

////// 3 táblázatnak 'C'
Route::post('/add_school', [AdminController::class, 'add_school']);
Route::post('/add_student', [AdminController::class, 'add_student']);
Route::post('/add_house', [AdminController::class, 'add_house']);

///// 3 táblázatnak 'D'
Route::get('/delete_school/{id}', [AdminController::class, 'delete_school']);
Route::get('/delete_student/{id}', [AdminController::class, 'delete_student']);
Route::get('/delete_house/{id}', [AdminController::class, 'delete_house']);

////3 táblázatnak 'U'
Route::get('/update_school/{id}', [AdminController::class, 'update_school']);
Route::get('/update_student/{id}', [AdminController::class, 'update_student']);
Route::get('/update_house/{id}', [AdminController::class, 'update_house']);
Route::post('/edit_school/{id}', [AdminController::class, 'edit_school']);
Route::post('/edit_student/{id}', [AdminController::class, 'edit_student']);
Route::post('/edit_house/{id}', [AdminController::class, 'edit_house']);

Route::get('/show_student', [AdminController::class, 'show_student']);
Route::get('/show_school', [AdminController::class, 'show_school']);
Route::get('/show_house', [AdminController::class, 'show_house']);Route::post('/edit_house/{id}', [AdminController::class, 'edit_house']);

/// 3 táblázat adatai egyben:
Route::get('/harom_tablazat', [AdminController::class, 'harom_tablazat'])->name('harom_tablazat');