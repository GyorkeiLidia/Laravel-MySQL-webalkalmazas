<?php
namespace App\Http\Controllers;

use App\Models\School;
use App\Models\Student;
use App\Models\House;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; //ellenőrzi,a user logged in-e

class AdminController extends Controller
{
    public function post_page(){
        return view('admin.post_page');
    }
    public function add_post(Request $request){
        $user=Auth()->user();  //nyíl után phpadminos user adatok
        $userid = $user->id;
        $name = $user->name;
        $usertype = $user->usertype;

        $post = new Post();
        $post->title = $request ->title; //első title phpmyadminból van, második viszont post_page.blade-ből!!!
        $post->description = $request ->description;
        $post->post_status = 'active';
        $post->user_id = $userid;  //phpadmin post adatok, összekapcsolva a useres adatokkal
        $post->name = $name;
        $post->usertype = $usertype;
        //fenti 3 sor magyarázat: első két adat post, harmadik user 
        ///////////elso 3 image kezdetű sor arra kell, hogy az image a public folderbe legyen
        $image=$request->image;

        if($image){  //if azért kell, hogy kép nélkül is postolhassunk
             $imagename=time().'.'.$image->getClientOriginalExtension();
             $request->image->move('postimage', $imagename); //az image-t a public folderben levő postimage folderbe küldjük
             /////////lenti 1 sor pedig azért, hogy az image a weboldalra kerüljön
             $post->image = $imagename;
        }

        $post->save(); //if nincs image, akkor jöhet a post és save
        return redirect()->back()->with('message', 'Sikeresen feltöltötted az új Post-ot');
    }//32. sorban, a postimage mappát magától generálja a laravel, csupán attól, hogy odairtuk és a képet is egyből oda mentette le!

    public function show_post(){
        $post = Post::all();
        return view('admin.show_post', compact('post'));
    }
    public function delete_post($id){
        $post = Post::find($id);
        $post -> delete();
        return redirect()->back()->with('message', 'Sikeresen Törölted a Postot.');
    }

    public function update_post($id){
        $post=Post::find($id); //kikeresi phpmyadminból az id-t
        return view('admin.update_post', compact('post'));   
    }

    /*public function edit_post(Request $request, $id){
        $data = Post::find($id);
        $data->title=$request->title;
        $data->description=$request->description;
        $image = $request->image;
        if($image){
            $imagename=time().'.'.$image->getClientOriginalExtension();
             $request->image->move('postimage', $imagename); //az image-t a public folderben levő postimage folderbe küldjük
             /////////lenti 1 sor pedig azért, hogy az image a weboldalra kerüljön
             $data->image = $imagename;
        }
        $data->save();
        return redirect()->back()->width('message', 'Sikeres módosítás');
    }*/

    public function edit_post(Request $request, $id){
        $data = Post::find($id);
        $data->title = $request->title;
        $data->description = $request->description;
        $image = $request->image;
        
        if($image){
            $imagename = time().'.'.$image->getClientOriginalExtension();
            $request->image->move('postimage', $imagename);
            $data->image = $imagename;
        }
    
        $data->save();
        return redirect()->back()->with('message', 'Sikeres módosítás');
    }

    //image downloadhoz:

    public function download_image($id){
        $post = Post::find($id);
        // Biztos van a poszthoz kép?
        if($post && $post->image){
            $path = public_path('postimage/'.$post->image);

            // Fájl létének ellenőrzése
            if(file_exists($path)){
                // Provide a download response
                return response()->download($path, $post->image);
            }
        }
        // Redirect back if the image is not found
        return redirect()->back()->with('message', 'A kép nem található!');
    }

    ///// 3 táblázat R egyben:
    public function harom_tablazat(){
        $schools = School::with('houses.students')->get();
        return view('admin.harom_tablazat', compact('schools'));
    }

    ///// SCHOOLS/ISKOLÁL functions (R, C, U, D)
    public function school_page(){
        return view('admin.school_page');
    }
    public function show_school(){
        $school = School::all();
        return view('admin.show_school', compact('school'));
    }
    public function add_school(Request $request){
        $user=Auth()->user();  //nyíl után phpadminos school adatok
        $userid = $user->id;
        $name = $user->name;
        $usertype = $user->usertype;
        $school = new School();
        $school->school_name = $request ->school_name; //első school_name phpmyadminból van, második viszont school_page.blade-ből!!!
        $school->save();
        return redirect()->back()->with('message', 'Sikeresen feltöltötted az új iskola nevet');
    }
    public function delete_school($id){
        $school = School::find($id);
        $school -> delete();
        return redirect()->back()->with('message', 'Sikeresen Törölted a Postot.');
    }
    public function update_school($id){
        $school=School::find($id); //kikeresi phpmyadminból az id-t
        return view('admin.update_school', compact('school'));   
    }

    public function edit_school(Request $request, $id){
        $data = School::find($id);
        $data->school_name=$request->school_name;
        $data->save();
        return redirect()->back()->with('message', 'Sikeres módosítás');
    }

    ///Csak a HOUSE/HÁZAK CUCCAI, azaz CRUD műveletei, stb
    public function house_page(){
        return view('admin.house_page');
    }
    public function add_house(Request $request){
        $user=Auth()->user();  //nyíl után phpadminos user adatok
        $userid = $user->id;
        $name = $user->name;
        $usertype = $user->usertype;
        $house = new House();
        $house->house_name = $request ->house_name;
        $house->school_id = $request ->school_id; //első school_name phpmyadminból van, második viszont school_page.blade-ből!!!
        $house->save();
        return redirect()->back()->with('message', 'Sikeresen feltöltötted az új iskola nevet');
    }
    public function show_house(){
        $house = House::all();
        return view('admin.show_house', compact('house'));
    }
    public function delete_house($id){
        $house = House::find($id);
        $house -> delete();
        return redirect()->back()->with('message', 'Sikeresen Törölted a Postot.');
    }
    public function update_house($id){
        $house=House::find($id); //kikeresi phpmyadminból az id-t
        return view('admin.update_house', compact('house'));   
    }
    public function edit_house(Request $request, $id){
        $data = House::find($id);
        $data->house_name=$request->house_name;
        $data->save();
        return redirect()->back()->with('message', 'Sikeres módosítás');
    }

    ///Csak a STUDENTS/DIÁKOK CUCCAI, azaz CRUD műveletei, stb
    public function student_page(){
        return view('admin.student_page');
    }
    public function add_student(Request $request){
        $user=Auth()->user();  //nyíl után phpadminos user adatok
        $userid = $user->id;
        $name = $user->name;
        $usertype = $user->usertype;
        $student = new Student();
        $student->student_name = $request ->student_name;
        $student->school_id = $request ->school_id; //első school_name phpmyadminból van, második viszont school_page.blade-ből!!!
        $student->house_id = $request ->house_id; //első school_name phpmyadminból van, második viszont school_page.blade-ből!!!
        $student->save();
        return redirect()->back()->with('message', 'Sikeresen feltöltötted az új iskola nevet');
    }
    public function show_student(){
        $student = Student::all();
        return view('admin.show_student', compact('student'));
    }
    public function delete_student($id){
        $student = Student::find($id);
        $student -> delete();
        return redirect()->back()->with('message', 'Sikeresen Törölted a Postot.');
    }

    public function update_student($id){
        $student=Student::find($id); //kikeresi phpmyadminból az id-t
        return view('admin.update_student', compact('student'));   
    }

    public function edit_student(Request $request, $id){
        $data = Student::find($id);
        $data->student_name=$request->student_name;
        $data->save();
        return redirect()->back()->with('message', 'Sikeres módosítás');
    }
}

