<div class="footer_section layout_padding">
    <div class="container">
       <div class="input_btn_main">
          <input type="text" class="mail_text" placeholder="Enter your email" name="Enter your email">
          <div class="subscribe_bt"><a href="#">Subscribe</a></div>
       </div>
       <div class="location_main">
          <div class="call_text"><img src="images/call-icon.png"></div>
          <div class="call_text"><a href="#">Call +01 1234567890</a></div>
          <div class="call_text"><img src="images/mail-icon.png"></div>
          <div class="call_text"><a href="#">demo@gmail.com</a></div>
       </div>
       <div class="social_icon">
          <ul>
             <li><a href="#"><img src="images/fb-icon.png"></a></li>
             <li><a href="#"><img src="images/twitter-icon.png"></a></li>
             <li><a href="#"><img src="images/linkedin-icon.png"></a></li>
             <li><a href="#"><img src="images/instagram-icon.png"></a></li>
          </ul>
       </div>
    </div>
 </div><?php /**PATH C:\Users\User\Desktop\wp3_masodik\wp3gyorkei2-app\resources\views/home/footer.blade.php ENDPATH**/ ?>