<!DOCTYPE html>
<html>
  <head> 
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
        .title_deg{
            font-size: 30px;
            font-weight: bold;
            color: white;
            padding: 30px;
            text-align: center;
        }
        .table_deg{
            border: 1px solid white;
            width: 80%;
            text-align: center;
            margin-left: 30px;
        }

        .th_deg{
            background-color: skyblue;
            color: black;
        }

        .img_deg{
            height: 100px;
            padding: 10px;
        }
    </style>
  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
    <div class="d-flex align-items-stretch"> <!--ez a sidebar és bodyhoz is tartozik, ezért itt hagyjuk! -->
      <!-- Sidebar Navigation-->
      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Sidebar Navigation end-->

      <div class="page-content">
        <?php if(session()->has('message')): ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" 
            aria-hidden="true">x</button>
            <?php echo e(session()->get('message')); ?>

        </div>
        <?php endif; ?>

        <h1 class="title_deg">Minden Post</h1>

        <table class="table_deg">
            <tr class="th_deg">
                <th>Post címe</th>
                <th>Leírás</th>
                <th>Készítette</th>
                <th>Post státusz</th>
                <th>user típusa</th>
                <th>Kép</th>
                <th>Törlés</th>
                <th>Javítás</th>
                <th>Kép letöltése</th>
            </tr>
<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr> <!--nyil után a phpmyadmin postos nevek jönnek -->
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->description); ?></td>
                <td><?php echo e($post->name); ?></td>
                <td><?php echo e($post->post_status); ?></td>
                <td><?php echo e($post->usertype); ?></td>
                <td><img class="img_deg" src="postimage/<?php echo e($post->image); ?>"></td>                
                <td>
                    <a href="<?php echo e(url('delete_post', $post->id)); ?>" class="btn btn-danger">Törlés</a>
                </td>
                <td>
                    <a href="<?php echo e(url('update_post', $post->id)); ?>" class="btn btn-success">Javítás</a>
                </td>
                <td>
                    <a href="<?php echo e(url('download_image/'.$post->id)); ?>" class="btn btn-success">Kép Letöltése</a>
                </td>

            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
        </table>
      </div>
      <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\Users\User\Desktop\wp3_masodik\wp3gyorkei2-app\resources\views/admin/show_post.blade.php ENDPATH**/ ?>