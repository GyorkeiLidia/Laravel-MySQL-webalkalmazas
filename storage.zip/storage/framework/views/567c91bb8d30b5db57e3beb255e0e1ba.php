<!DOCTYPE html>
<html>
  <head> 
    <base href="/public">
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
        .post_title{
            font-size: 30px;
            font-weight: bold;
            text-align: center;
            padding: 30px;
            color: white;
        }
        .div_center{
            padding: 30px;
            text-align: center;
        }
        label{
            display: inline-block;
            width: 200px;
        }
    </style>
  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex align-items-stretch"> <!--ez a sidebar és bodyhoz is tartozik, ezért itt hagyjuk! -->
      <!-- Sidebar Navigation-->
      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <h1 class="post_title">Poszt Szerkesztése</h1>
        <div>
            <form action="<?php echo e(url('edit_post', $post->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="div_center">
                    <label>Poszt Címe</label>
                    <input type="text" name="title" value="<?php echo e($post->title); ?>"><!--eredeti szöveget mutatja! -->
                </div>
                <div class="div_center">
                    <label>Poszt Leírása</label>
                    <textarea name="description"><?php echo e($post->description); ?></textarea>
                </div>
                <div class="div_center">
                    <label>Régi kép</label>
                    <img stye="margin:auto" height="100px" src="/postimage/<?php echo e($post->image); ?>">
                </div>
                <div class="div_center">
                    <label>Régi kép újra cserélése</label>
                    <input type="file" name="image">
                </div>
                <div class="div_center">
                    <input type="submit" class="btn btn-primary">
                </div>
            </form>
        </div>
      </div>  
      <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\Users\User\Desktop\wp3_masodik\wp3gyorkei2-app\resources\views/admin/update_post.blade.php ENDPATH**/ ?>