<nav id="sidebar">
    <!-- Sidebar Header-->
    <div class="sidebar-header d-flex align-items-center">
      <div class="avatar"><img src="admincss/img/avatar-6.jpg" alt="..." class="img-fluid rounded-circle"></div>
      <div class="title">
        <h1 class="h5">Györkei Lidia</h1>
        <p>Webprogramozás III.</p>
      </div>
    </div>
    <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
    <ul class="list-unstyled">
            <li class="active"><a href="index.html"> <i class="icon-home"></i>Főoldal</a></li>
            <li><a href="{{url('post_page')}}"> <i class="icon-grid"></i>Új Post </a></li>
            <li><a href="{{url('show_post')}}"> <i class="fa fa-bar-chart"></i>Post read delete</a></li>
            <li><a href="{{url('harom_tablazat')}}"> <i class="icon-padnote"></i>3 táblázat egyben</a></li>
            <li><a href="#exampledropdownDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-windows"></i>Hozzáadás 3 táblázathoz </a>
              <ul id="exampledropdownDropdown" class="collapse list-unstyled ">
                <li><a href="{{url('school_page')}}">Új Iskola hozzáadása</a></li>
                <li><a href="{{url('house_page')}}">Új Ház hozzáadása</a></li>
                <li><a href="{{url('student_page')}}">Új Diák hozzáadása</a></li>
              </ul>
            </li>
            <li><a href="{{url('show_school')}}"> <i class="fa fa-bar-chart"></i>Iskola read delete</a></li>
            <li><a href="{{url('show_house')}}"> <i class="fa fa-bar-chart"></i>Ház read delete</a></li>
            <li><a href="{{url('show_student')}}"> <i class="fa fa-bar-chart"></i>Diák read delete</a></li>
    </ul><span class="heading">Extras</span>
  </nav>