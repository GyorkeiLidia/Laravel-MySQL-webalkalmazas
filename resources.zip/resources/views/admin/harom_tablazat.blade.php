<!DOCTYPE html>
<html>
  <head> 
    @include('admin.css')
    <style type="text/css">
        .harom_title{
            font-size: 30px;
            font-weight: bold;
            color: white;
            padding: 30px;
            text-align: center;
        }
        .table_deg{
            border: 1px solid white;
            width: 80%;
            text-align: center;
            margin-left: 30px;
        }
        .th_deg{
            background-color: skyblue;
            color: black;
        }
    </style>

  </head>
  <body>
    @include('admin.header')
 
    <div class="d-flex align-items-stretch"> <!--ez a sidebar és bodyhoz is tartozik, ezért itt hagyjuk! -->
      <!-- Sidebar Navigation-->
      @include('admin.sidebar')
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <h1 class="harom_title">Három Táblázat Egyben:</h1>
        <a href="{{ route('harom_tablazat') }}"></a>
        <table class="table_deg">
            <tr class="th_deg">
                <th>Diák neve</th>
                <th>Iskola neve</th>
                <th>Ház neve</th>
            </tr>
@foreach($schools as $school)
                @foreach($school->houses as $house)
                    @foreach($house->students as $student)
            <tr> <!--nyil után a phpmyadmin postos nevek jönnek -->
                <td>{{$student->student_name}}</td>
                <td>{{$school->school_name}}</td>
                <td>{{$house->house_name}}</td>
            </tr>
            @endforeach
        @endforeach
@endforeach            
        </table>

      </div>

      @include('admin.footer')
       
  </body>
</html>




