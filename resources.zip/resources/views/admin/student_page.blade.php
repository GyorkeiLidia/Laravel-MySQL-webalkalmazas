<!DOCTYPE html>
<html>
  <head> 
    @include('admin.css')
    <style type="text/css">
        .student_title{
            font-size: 30px;
            font-weight: bold;
            text-align: center;
            padding: 30px;
            color: white;
        }
        .div_center{
            padding: 30px;
            text-align: center;
        }
        label{
            display: inline-block;
            width: 200px;
        }
    </style>
  </head>
  <body>
    @include('admin.header')
    <div class="d-flex align-items-stretch"> <!--ez a sidebar és bodyhoz is tartozik, ezért itt hagyjuk! -->
        <!-- Sidebar Navigation-->
        @include('admin.sidebar')
        <!-- Sidebar Navigation end-->
        <div class="page-content">
            @if(session()->has('message'))  <!--if condition sikeres post message miatt kell -->
            <div class="alert alert success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                {{session()->get('message')}}
            </div>
            @endif
            <h1 class="student_title">Új Diák Hozzáadása</h1>
            <div>
                <form action="{{url('add_student')}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="div_center">
                        <label>Diák Neve</label>
                        <input type="text" name="student_name">
                    </div>
                    <div class="div_center">
                        <label>Iskola Sorszáma</label>
                        <input type="text" name="school_id">
                    </div>
                    <div class="div_center">
                        <label>Ház Sorszáma</label>
                        <input type="text" name="house_id">
                    </div>
                    <div class="div_center">
                        <input type="submit" class="btn btn-primary">
                    </div>
                </form>
                
            </div>
            @include('admin.footer')
        </div>
  </body>
</html>