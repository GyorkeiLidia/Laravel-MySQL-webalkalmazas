<!DOCTYPE html>
<html>
  <head> 
    @include('admin.css')
  </head>
  <body>
    @include('admin.header')
 
    <div class="d-flex align-items-stretch"> <!--ez a sidebar és bodyhoz is tartozik, ezért itt hagyjuk! -->
      <!-- Sidebar Navigation-->
      @include('admin.sidebar')
      <!-- Sidebar Navigation end-->
      @include('admin.body')

      @include('admin.footer')
       
  </body>
</html>