<!DOCTYPE html>
<html>
  <head> 
    <base href="/public">
    @include('admin.css')
    <style type="text/css">
        .house_title{
            font-size: 30px;
            font-weight: bold;
            text-align: center;
            padding: 30px;
            color: white;
        }
        .div_center{
            padding: 30px;
            text-align: center;
        }
        label{
            display: inline-block;
            width: 200px;
        }
    </style>
  </head>
  <body>
    @include('admin.header')
    <div class="d-flex align-items-stretch"> <!--ez a sidebar és bodyhoz is tartozik, ezért itt hagyjuk! -->
      <!-- Sidebar Navigation-->
      @include('admin.sidebar')
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        @if(session()->has('message'))  <!--if condition sikeres post message miatt kell -->
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
            {{session()->get('message')}}
        </div>
        @endif
        <h1 class="house_title">Ház Megváltoztatása</h1>
          <div>
            <form action="{{url('edit_house', $house->id)}}" method="POST" enctype="multipart/form-data">
              @csrf
              <div class="div_center">
                <label>Ház Neve</label>
                <input type="text" name="house_name" value="{{$house->house_name}}"><!--eredeti szöveget mutatja! -->
              </div>
              <div class="div_center">
                <input type="submit" class="btn btn-primary">
              </div>
            </form>
          </div>  
      </div>
      @include('admin.footer')
    </div>
  </body>
</html>