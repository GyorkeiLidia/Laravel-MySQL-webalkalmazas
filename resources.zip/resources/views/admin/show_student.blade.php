<!DOCTYPE html>
<html>
  <head> 
    @include('admin.css')
    <style type="text/css">
        .title_deg{
            font-size: 30px;
            font-weight: bold;
            color: white;
            padding: 30px;
            text-align: center;
        }
        .table_deg{
            border: 1px solid white;
            width: 80%;
            text-align: center;
            margin-left: 30px;
        }

        .th_deg{
            background-color: skyblue;
            color: black;
        }

        .img_deg{
            height: 100px;
            padding: 10px;
        }
    </style>
  </head>
  <body>
    @include('admin.header')
 
    <div class="d-flex align-items-stretch"> <!--ez a sidebar és bodyhoz is tartozik, ezért itt hagyjuk! -->
      <!-- Sidebar Navigation-->
      @include('admin.sidebar')
      <!-- Sidebar Navigation end-->

      <div class="page-content">
        @if(session()->has('message'))
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" 
            aria-hidden="true">x</button>
            {{session()->get('message')}}
        </div>
        @endif
        <h1 class="title_deg">Csak a diákok nevei</h1>
        <table class="table_deg">
            <tr class="th_deg">
                <th>Diák neve</th>
                <th>Törlés</th>
                <th>Módosítás</th>
            </tr>
@foreach ($student as $student)
            <tr> <!--nyil után a phpmyadmin postos nevek jönnek -->
                <td>{{$student->student_name}}</td>
                <td>
                    <a href="{{url('delete_student', $student->id)}}" class="btn btn-danger">Törlés</a>
                </td>
                <td>
                    <a href="{{url('update_student', $student->id)}}" class="btn btn-success">Javítás</a>
                </td>
            </tr>
@endforeach            
        </table>
      </div>
      @include('admin.footer')
  </body>
</html>