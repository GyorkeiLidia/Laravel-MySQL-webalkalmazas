<div class="banner_section layout_padding">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
       <div class="carousel-inner">
          <div class="carousel-item active">
             <div class="container">
                <h1 class="banner_taital">Webprogramozás III.</h1>
                <p class="banner_text">Lorem Ipsum available, but the majority have sufferedThere are ma available, but the majority have suffered</p>
                <div class="read_bt"><a href="#">Get A Quote</a></div>
             </div>
          </div>
          <div class="carousel-item">
             <div class="container">
                <h1 class="banner_taital">Programtervező Informatikus Szak</h1>
                <p class="banner_text">There are many variations of passages of Lorem Ipsum available, but the majority have sufferedThere are ma available, but the majority have suffered</p>
                <div class="read_bt"><a href="#">Get A Quote</a></div>
             </div>
          </div>
          <div class="carousel-item">
             <div class="container">
                <h1 class="banner_taital">Eszterházy Károly Egyetem</h1>
                <p class="banner_text">There are many variations of passages of Lorem Ipsum available, but the majority have sufferedThere are ma available, but the majority have suffered</p>
                <div class="read_bt"><a href="#">Get A Quote</a></div>
             </div>
          </div>
       </div>
    </div>
 </div>